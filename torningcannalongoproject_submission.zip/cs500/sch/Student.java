package cs500.sch;

public class Student implements Cloneable {
	  
	  private String ssn;
	  private String name;
	  private String street, city;
	  private String res_state;
	  private String sex;
	  private String us_citizen;
	  private String dob;
	  private String ethnicity;
	  private String college;
	  private String major;
	  private String college_gpa;
	  private String hs;
	  private String hs_grad_year;
	  private String hs_class_rank;
	  private String hs_gpa;
	  
	 
	  public Student(String ssn, String name, String street, String city, String res_state, String sex, String us_citizen,
				String dob, String ethnicity, String college, String major, String college_gpa, String hs, String hs_grad_year,
				String hs_class_rank, String hs_gpa) {
			super();
			this.ssn = ssn;
			this.name = name;
			this.street = street;
			this.city = city;
			this.res_state = res_state;
			this.sex = sex;
			this.us_citizen = us_citizen;
			this.dob = dob;
			this.ethnicity = ethnicity;
			this.college = college;
			this.major = major;
			this.college_gpa = college_gpa;
			this.hs = hs;
			this.hs_grad_year = hs_grad_year;
			this.hs_class_rank = hs_class_rank;
			this.hs_gpa = hs_gpa;
		}

	 

	public String toString() {
	    return ssn + " : " + name;
	}
	  
	public String toHTML() {
		return "<tr><td>" + ssn + "</td><td>" + name + "</td></tr>";
	}

	public String getSsn() {
		return ssn;
	}

	public String getName() {
		return name;
	}

	public String getStreet() {
		return street;
	}

	public String getCity() {
		return city;
	}

	public String getRes_state() {
		return res_state;
	}

	public String getSex() {
		return sex;
	}

	public String isUs_citizen() {
		return us_citizen;
	}

	public String getDob() {
		return dob;
	}

	public String getEthnicity() {
		return ethnicity;
	}

	public String getCollege() {
		return college;
	}

	public String getMajor() {
		return major;
	}

	public String getCollege_gpa() {
		return college_gpa;
	}

	public String getHs() {
		return hs;
	}

	public String getHs_grad_year() {
		return hs_grad_year;
	}

	public String getHs_class_rank() {
		return hs_class_rank;
	}

	public String getHs_gpa() {
		return hs_gpa;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setRes_state(String abbr) {
		this.res_state = abbr;
	}

	public String setSex() {
		return sex;
	}

	public String setUs_citizen() {
		return us_citizen;
	}

	public String setDob() {
		return dob;
	}

	public String setEthnicity() {
		return ethnicity;
	}

	public String setCollege() {
		return college;
	}

	public String setMajor() {
		return major;
	}

	public String setCollege_gpa() {
		return college_gpa;
	}

	public String setHs() {
		return hs;
	}

	public String setHs_grad_year() {
		return hs_grad_year;
	}

	public String setHs_class_rank() {
		return hs_class_rank;
	}

	public String setHs_gpa() {
		return hs_gpa;
	}
}

