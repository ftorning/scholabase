package cs500.sch;

import java.util.*;

public class HTMLBuilder {
	public static String buildOpening() {
		StringBuffer sb = new StringBuffer(); 
		sb.append("<html><body><form action=\"scodb\" method=\"POST\">");
		sb.append("<h2> Would you like information about...</h2><p>");
		sb.append("<input type=\"radio\" name=\"qrytype\" value=\"default\" display:\"none\"	/>");
		sb.append("<input type=\"radio\" name=\"qrytype\" value=\"students\" />Students");
		sb.append("<input type=\"radio\" name=\"qrytype\" value=\"companies\" />Companies");
		sb.append("<input type=\"submit\" value=\"Select Subject\" />");
		sb.append("</form>");
		return sb.toString();
		}
		
	public static String buildList(ArrayList list) {
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		for(Object e : list) {
				sb.append(e.toString());
		}
		sb.append("</table>");
		return sb.toString();
	}
	
	public static String buildCompanyChecklist(ArrayList<Company> list) {
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		
		for (Company e : list) {
				sb.append("<tr><td>");
				sb.append("<input type=\"radio\" name=\"company" + "\" value=\"" + e.getCompanyId() + "\">" + e.getName());
				sb.append("</tr></td>");
			}
		
		sb.append("</table>");
		return sb.toString();
	}
	
	public static String listCompanies(ArrayList<Company> list)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		for (Company c : list)
		{
			sb.append(c.toHTML());
		}
		sb.append("</table>");
		return sb.toString();
	}
	
		public static String listStudents(ArrayList<Student> list)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		for (Student c : list)
		{
			sb.append(c.toHTML());
		}
		sb.append("</table>");
		return sb.toString();
	}
	
	public static String buildCompanyQryRadios() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html><body><form action=\"scodb\" method=\"POST\">");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"countscol\"/> How many scholarships does each company offer? <br>");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"valscol\"  /> What is the total value of all scholarships each offers? <br>");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"allscol\"  /> Show some info about each scholarship the each offers. <br>");
		sb.append("<input type=\"submit\" value=\"Get Company Scholarship Data\" /> <br><br>");
		sb.append("</form>");
		return sb.toString();
	}
	
		public static String buildApplicantQryRadios() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html><body><form action=\"scodb\" method=\"POST\">");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"appel\"/> How many scholarships is each applicant eligible for? <br>");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"apphs\"  /> Which students attended impoverished high schools? <br>");
		sb.append("<input type=\"radio\" name=\"finalqry\" value=\"appminp\"  /> Which minority students are attending private colleges? <br>");
		//sb.append("<input type=\"radio\" name=\"finalqry\" value=\"allscol\"  /> . <br>");
		sb.append("<input type=\"submit\" value=\"Get Student Data\" /> <br><br>");
		sb.append("</form>");
		return sb.toString();
	}
	
		public static String buildCompanyTxtQry() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html><body><form action=\"scodb\" method=\"POST\">");
		sb.append("Which companies list more than ");
		sb.append("<input type=\"text\" name=\"grtcount\"> scholarships?");
		sb.append("<input type=\"submit\" value=\"Get Scholarship Data\" />");
		sb.append("</form>");
		return sb.toString();
	}
	
}