package cs500.sch;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.*;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 */
public class ScholarBaseServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private ScholarBase scb;
    private String _message;
	private ArrayList<Company> companies;
	private ArrayList<Student> applicants;

    public void init() throws ServletException {
	scb = new ScholarBase();
	_message = scb.openDBConnection("PgBundle");
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
  
	response.setContentType("text/html");

	PrintWriter out = response.getWriter();
	out.println(HTMLBuilder.buildOpening());
	
	
     out.println("</body></html>");
    
	
	
	try {switch (request.getParameter("qrytype")) {
		case "students": 
			applicants = scb.getApplicants();
			out.println("All active applicants in ScholarBase: <br> <br>");
			out.println(HTMLBuilder.listStudents(applicants));
			out.println("What do you want to know about them?");
			out.println(HTMLBuilder.buildApplicantQryRadios());
			
			
			break;
		case "companies":
			companies = scb.getSponsors();
			out.println("All Active Companies in ScholarBase: <br><br>" );
			out.println(HTMLBuilder.listCompanies(companies));
			out.println("What do you want to know about them?");
			out.println(HTMLBuilder.buildCompanyQryRadios());
			break;
		default: 		 
			out.println("You have not made a selection yet"); break;
	} } catch (SQLException e) {out.println(e.getMessage());} catch (NullPointerException e) {}
	
	
	try {
		String argType = new String();
		ArrayList<String> args = new ArrayList<String>();
	
		switch (request.getParameter("finalqry")) {
			case "allscol":
				out.println("You have selected info about all scholarships. <br> A business without any listings does not have any active scholarship offerings.");
				out.println(scb.doQuery("allscol"));
				break;
			case "valscol":
				out.println("You have selected info about scholarship value. <br> Businesses without scholarship offerings will have a 'null' value.");
				out.println(scb.doQuery("valscol"));
				break;
			case "countscol":
				out.println("You have selected info about scholarship counts. <br> A business without a listing does not have any active scholarship offerings.");
				out.println("<br>");
				if (args.size() == 0) {out.println(scb.doQuery("countscol"));}
				break;
			case "appel":
				out.println("You have selected info about student eligibility.");
				out.println(scb.doQuery("appel"));
				break;
			case "apphs":
				out.println("You have selected info about each student's high school");
				out.println(scb.doQuery("apphs"));
				break;
			case "appminp":
				out.println("You have selected info about minority students at private colleges.");
				out.println(scb.doQuery("appminp"));
				break;
			default: break;
		}
	}	catch (NullPointerException e) {} catch (SQLException s) {out.println(s.getMessage());}
	}
	
  
    public void doPost(HttpServletRequest inRequest, HttpServletResponse outResponse) 
	throws ServletException, IOException {  
	
	doGet(inRequest, outResponse);  
    }

    public void destroy() {
	scb.closeDBConnection();
    }
}
