package cs500.sch;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

/**
 * 
 * Based on the Registrar implementation provided by Julia Stoyanovich (stoyanovich@drexel.edu) 
 *
 */
public class ScholarBase {
  
  private static Connection _conn = null;
  private static ResourceBundle _bundle;
  private static HashMap<String, String> bQueries;
  
  /**
   * 
   * @param bundle - resource bundle that contains database connection information
   * @return
   */

	public ScholarBase()
	{
		bQueries = new HashMap<String, String>();
		createBaseQueries();
	}
  public String openDBConnection(String bundle) {
	 _bundle = ResourceBundle.getBundle(bundle);
	 return openDBConnection(
			 _bundle.getString("dbUser"), 
			 _bundle.getString("dbPass"),
			 _bundle.getString("dbSID"), 
			 _bundle.getString("dbHost"), 
			 Integer.parseInt(_bundle.getString("dbPort"))
			 );
  }
  
  /**
   * Open the database connection.
   * @param dbUser
   * @param dbPass
   * @param dbSID
   * @param dbHost
   * @return
   */
  public String openDBConnection(String dbUser, String dbPass, String dbSID, String dbHost, int port) {
    
    String res="";
    if (_conn != null) {
      closeDBConnection();
    }
  
    try {
       _conn = DBUtils.openDBConnection(dbUser, dbPass, dbSID, dbHost, port);
       res = DBUtils.testConnection(_conn);
    } catch (SQLException sqle) {
      sqle.printStackTrace(System.err);
    } catch (ClassNotFoundException cnfe) {
      cnfe.printStackTrace(System.err);
    }
    return res;
  }
  
  /**
   * Close the database connection.
   */
  public void closeDBConnection() {
    try {
      DBUtils.closeDBConnection(_conn);
      System.out.println("Closed a connection");
    } catch (SQLException sqle) {
      sqle.printStackTrace(System.err);
    }
  }
  
  /**
   * Register a new Company in the database.
   * @param newCompany
   * @return
   */
   /*
 
  public Company registerCompany(Company newCompany) {
    try {
      int sid = 1 + DBUtils.getIntFromDB(_conn, "select max(sid) from Company");
      newCompany.setId(sid);
      String query = "insert into Companys (sid, name) values ("  + 
                newCompany.getId() + ", '" + newCompany.getName() + "')";
      DBUtils.executeUpdate(_conn, query);
    } catch (SQLException sqle) {
       sqle.printStackTrace(System.err);
    }
    return newCompany;
  }
  */
  
  /**
   * Update the Company's GPA in the database.
   * @param sid
   * @param gpa
   * @return
   
  public Company setGPA(int sid, double gpa) {
    Company Company = null;
    try {
      int cnt = DBUtils.getIntFromDB(_conn, "select count(*) from Companys where sid = " + sid);
      if (cnt == 0) {
        return Company;
      }
      String query = "update Companys set gpa = " + gpa + " where sid = " + sid;
      DBUtils.executeUpdate(_conn, query);
      
      query = "select name, gpa from Companys where sid = " + sid;
      Statement st = _conn.createStatement();
        ResultSet rs = st.executeQuery(query);
        rs.next();
        
        Company = new Company(sid, rs.getString("name"), rs.getDouble("gpa"));
        
        rs.close();
        st.close();
    } catch (SQLException sqle) {
      sqle.printStackTrace(System.err);
    }
    return Company;
  }
  */
  
  /**
   * Get the complete list of company sponsors
   * @return
   */
   public ArrayList<Company> getSponsors() throws SQLException {
     
		//get companies that actually have a scholarship listed
       ArrayList<Company> sponsors = new ArrayList<Company>();
       
       String query = "select company_id, name, company_state, industry, is_publicly_held from company order by company_id asc";
      
       Statement st = _conn.createStatement();
        ResultSet rs = st.executeQuery(query);
        
        while (rs.next()) {
        
          String cid = rs.getString("company_id");
          String name = rs.getString("name");
          String state = rs.getString("company_state");
		  String industry = rs.getString("industry");
		  boolean is_public = rs.getBoolean("is_publicly_held");
          Company company = new Company(cid, name, state, industry, is_public);
           
          sponsors.add(company);
        }
        
        rs.close();
        st.close();

    return sponsors;
   
    }
	
	   public ArrayList<Student> getApplicants() throws SQLException {
     
		//get companies that actually have a scholarship listed
       ArrayList<Student> applicants = new ArrayList<Student>();
       
       String query = "select ssn, name, street, city, res_state, sex, us_citizen, dob, ethnicity, college_major, college, college_gpa, academic_probation, high_school, hs_grad_Year, hs_gpa, hs_class_rank from student";
      
       Statement st = _conn.createStatement();
        ResultSet rs = st.executeQuery(query);
        
        while (rs.next()) {
        
          String ssn = rs.getString("ssn");
		  String name = rs.getString("name");
		  String street = rs.getString("street");
		  String city = rs.getString("city");
		  String res_state = rs.getString("res_state");
		  String sex = rs.getString("sex");
		  String us_citizen = rs.getString("us_citizen");
		  String dob = rs.getString("dob");
		  String ethnicity = rs.getString("ethnicity");
		  String college = rs.getString("college");
		  String major = rs.getString("college_major");
		  String college_gpa = rs.getString("college_gpa");
		  String hs = rs.getString("high_school");
		  String hs_grad_year = rs.getString("hs_grad_year");
		  String hs_class_rank = rs.getString("hs_class_rank");
		  String hs_gpa = rs.getString("hs_gpa");
		  
		  
          Student stu = new Student(ssn, name, street, city, res_state, sex, us_citizen, dob, ethnicity, college, major, college_gpa, hs, hs_grad_year, hs_class_rank, hs_gpa);
           
          applicants.add(stu);
        }
        
        rs.close();
        st.close();

    return applicants;
   
    }
	
	
	public String doQuery(String qry) throws SQLException 
	{
		StringBuffer sb = new StringBuffer();
		String finalQuery = new String();
		Statement st = _conn.createStatement();
        ResultSet rs = st.executeQuery(bQueries.get(qry));
		ResultSetMetaData rsmd = rs.getMetaData();
		int cols = rsmd.getColumnCount();
		
		
		while (rs.next())
			{
				sb.append("<LI>");
				for (int i = 1; i <= cols; i++) {
				sb.append(rs.getString(i) + " | ");
				}
				sb.append("</LI>\n");
			sb.append("</UL>");
		}
		sb.append("Query successful");
		rs.close();
		st.close();	
		
		return sb.toString();
	
	}
  
  public void addTermsDynamicSQL(String [] terms) {
    
      for (int i=0; i<terms.length; i++) {
	    String term = terms[i];
	    try {
		String query = "insert into Terms values ('" + term + "')";
		DBUtils.executeUpdate(_conn, query);
	    } catch (SQLException sqle) {
		System.out.println("Insert into Terms failed for " + term);
	    }
      }
  }
  
  public void addTermsPreparedStatement(String [] terms) {
      try {
	  String query = "insert into Terms values ( ? )";
	  DBUtils.executeUpdate(_conn, query, terms);
      } catch (SQLException sqle) {
	  System.out.println(sqle.toString());
      }
  }
  
  private void createBaseQueries()
  {
	  bQueries.put("countscol", "select name , count(sco_id) schcnt from company join scholarship on company.company_id = scholarship.company_id group by company.company_id, name order by count(sco_id) desc");
	  bQueries.put("valscol", "select cm.name COMPANY, sum(sc.dollar_value) VALUE_ALL_SCHOLARSHIPS from company cm left join scholarship sc on cm.company_id = sc.company_id group by cm.name order by sum(sc.dollar_value) desc");
	  bQueries.put("allscol", "select cm.name, sc.title, sc.dollar_value from company cm join scholarship sc on cm.company_id = sc.company_id");
	  bQueries.put("grtcount", "select name, count(sco_id) from company join scholarship on company.company_id = scholarship.company_id group by name order by count(sco_id) desc");
	  bQueries.put("appminp", "select st.ssn, st.name, st.ethnicity, co.college_name from student st join ethnicity et on st.ethnicity  = et.ethnicity join college co on st.college = co.college_id where et.is_minority = TRUE and co.is_public = FALSE");
	  bQueries.put("apphs", "select st.name, hs.name from student st join high_school hs on st.high_school = hs.school_id where hs.is_impoverished = TRUE");
	  bQueries.put("abc", "select name, company_state, industry, is_publicly_held from company");
	  bQueries.put("appel", "select s.name, s.res_state, s.sex, e.is_minority, m.is_stem, sc.title, sc.minority_restriction, sc.gender_restriction, sc.state_restriction, sc.stem_restriction from  student s inner join ethnicity e on s.ethnicity = e.ethnicity inner join majors m on m.major_id = s.college_major cross join scholarship sc where (s.sex = sc.gender_restriction OR sc.gender_restriction IS NULL) AND (s.res_state = sc.state_restriction OR sc.state_restriction IS NULL) AND (e.is_minority = sc.minority_restriction OR sc.minority_restriction IS NULL) AND (m.is_stem = sc.stem_restriction OR sc.stem_restriction IS NULL) order by s.name");
  }
  
  public String getQuery(String key)
  {
	  return bQueries.get(key);
  }
  
  private String addWhere(String bQuery, String arg, ArrayList<String> args) {
	  StringBuffer sb = new StringBuffer();
	  
	  //encapsulate base query
	  sb.append("select * from (" + bQuery + ")");
	  sb.append("where " + arg + " = " + args.get(0));
	  return sb.toString();
  }
  
  	public String doQuery(String qry, String argType, ArrayList<String> args) throws SQLException 
	{
		StringBuffer sb = new StringBuffer();
		String baseQuery = bQueries.get(qry);
		String finalQuery = addWhere(baseQuery, argType, args);
		
		
		Statement st = _conn.createStatement();
        ResultSet rs = st.executeQuery(finalQuery);
		ResultSetMetaData rsmd = rs.getMetaData();
		int cols = rsmd.getColumnCount();
		
		
		while (rs.next())
			{
				sb.append("<LI>");
				for (int i = 1; i <= cols; i++) {
				sb.append(rs.getString(i) + " | ");
				}
				sb.append("</LI>\n");
			sb.append("</UL>");
		}
		sb.append("Query successful");
		rs.close();
		st.close();	
		
		return sb.toString();
	
	}
  
}
